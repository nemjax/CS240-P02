#include "GameObject.h"
//default in all bool will be false
class EnemyShip:GameObject
{
	isAlive = true;
	isAbleToShoot = true;
	isMovable = true;
	isShooting = false;

};

class Bullet:GameObject
{
	isAlive = true;
	isBullet = true;
	isAbleToShoot = true;
	isMovable = true;

};

class Player:GameObject
{
	isAlive = true;
	isAbleToShoot = true;
	isMovable = true;
	isPlayer = true;
};
