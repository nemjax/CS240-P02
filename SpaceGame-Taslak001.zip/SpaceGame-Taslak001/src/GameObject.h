#ifndef GAMEOBJECT_H
#define GAMEOBJECT_H
 
#include "SDL2/SDL.h"
#include <string>
#include "Move"

class GameObject:Move
{
	public:
		GameObject(std::string imageFilename);

		void Move(int newX, int newY); // handles moving objects

		SDL_Surface* getSurface();
		void behavior(); // behavior of the each type of object that is gonna inherate from game object 
		void updateShootings(); // will control isShooting
		void updateHealth(); //if health==0 isAlive = false; will control is Alive
		void checkCollision(); //will control collapsed


		int getValue();
		int getX();
		int getY();
		
	private:
		bool isAbleToShoot; //1> for shooting objects 0>not shooting 		
		bool isShooting; //if true create bullet Objects
		bool isAlive; //if false self destruct 
		bool collapsed; 
		bool isBullet; // ex: if that gameObject "isBullet" and player.collapsed() then player.value -= bullet.value
		bool isMovable; //F for meteors and such 
		bool isPlayer//everything needs to or may need to be modified it the GO is player
		int value; //health for player and ships damage for bullets

		SDL_Surface* surf;
		int x;
		int y;

};


#endif

class Move 
{
	public:
		 void move(int newX, int newY)
		{
			x = newX;
			y = newY;
		}
	private:
		int x = 0;
		int y;

};
